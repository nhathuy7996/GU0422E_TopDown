using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    [SerializeField] float _speed, _dmg, _lifeTime;
    [SerializeField] Rigidbody2D _rigi;

    Vector2 _movement = Vector2.zero;
    // Start is called before the first frame update
    void Start()
    {
        if(_rigi == null)
            _rigi = this.GetComponent<Rigidbody2D>();


    }

    public void Init(float speed, float dmg, float lifeTime, Vector2 movement) {
        this._speed = speed;
        this._dmg = dmg;
        this._lifeTime = lifeTime;
        this._movement = movement;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        _rigi.velocity = _movement * _speed;
    }
}
