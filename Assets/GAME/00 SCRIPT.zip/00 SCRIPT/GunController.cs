using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour
{
    PlayerController _player;
    [SerializeField] bullet _bullet;

    [SerializeField] float _bulletSpeed, _bulletDamage, _lifeTime;

    public void Init(PlayerController player) {
        this._player = player;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Fire() {
       Instantiate<bullet>(_bullet, this.transform.position, Quaternion.identity ).
            Init(_bulletSpeed, _bulletDamage, _lifeTime,_player.transform.right);
    }
}
